import {useRef, useEffect} from 'react';
import * as d3 from 'd3';

export default function Treemap({data, width, height}) {
  const svgRef = useRef(null);

  function renderTreemap() {
    const svg = d3.select(svgRef.current);

    svg.attr('width', width).attr('height', height).attr('overflow', 'hidden');

    const root = d3
      .hierarchy(data)
      .sum((d) => d.value)
      .sort((a, b) => b.value - a.value);

    const treemapRoot = d3
      .treemap()
      .size([width, height])
      .padding(1)
      .paddingOuter(0)(root);

    const nodes = svg
      .selectAll('g')
      .data(treemapRoot.leaves())
      .join('g')
      .attr('transform', (d) => `translate(${d.x0},${d.y0})`);

    // const fader = (color) => d3.interpolateRgb(color, '#fff')(0.3);
    // const colorScale = d3.scaleOrdinal(d3.schemeCategory10.map(fader));
    const colorScale = d3.scaleOrdinal().range(data.range);

    nodes
      .append('rect')
      .attr('width', (d) => d.x1 - d.x0)
      .attr('height', (d) => d.y1 - d.y0)
      .attr('fill', (d) => colorScale(d.data.name));

    const fontSize = 16;

    nodes
      .append('text')
      .text((d) => `${d.data.name}`)
      .attr('data-width', (d) => d.x1 - d.x0)
      .attr('font-size', `${fontSize}px`)
      .attr('font-weight', 'semibold')
      .attr('x', (d) => (d.x1 - d.x0) / 2)
      .attr('y', (d) => (d.y1 - d.y0) / 2)
      .attr('text-anchor', 'middle')
      .attr('dominant-baseline', 'middle')
      .call(wrapText);

    function wrapText(text) {
      text.each(function () {
        var textEl = d3.select(this),
          words = textEl.text().split(/\s+/).reverse(),
          word,
          line = [],
          linenumber = 0,
          lineHeight = 1.1, // ems
          x = textEl.attr('x'),
          y = textEl.attr('y'),
          width = textEl.attr('data-width'),
          dx = parseFloat(textEl.attr('dx') || 0),
          dy = parseFloat(textEl.attr('dy') || 0),
          tspan = textEl
            .text(null)
            .append('tspan')
            .attr('x', x)
            .attr('y', y)
            .attr('dy', dy + 'em');

        while ((word = words.pop())) {
          line.push(word);
          tspan.text(line.join(' '));
          if (tspan.node().getComputedTextLength() > width) {
            line.pop();
            tspan.text(line.join(' '));
            line = [word];
            tspan = textEl
              .append('tspan')
              .attr('x', x)
              .attr('y', y)
              .attr('dx', dx)
              .attr('dy', ++linenumber * lineHeight + dy + 'em')
              .text(word);
          }
        }
      });
    }
  }

  useEffect(() => {
    renderTreemap();
  }, [data]);

  return (
    <div
      style={{
        borderRadius: '16px',
        width: width,
        height: height,
        overflow: 'hidden',
      }}
    >
      <svg ref={svgRef} />
    </div>
  );
}
