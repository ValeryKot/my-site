import React from 'react';
import ReactApexChart from 'react-apexcharts';

const options = {
  legend: {
    show: false,
  },
  chart: {
    type: 'treemap',
    background: 'none',
    toolbar: {
      show: false,
    },
  },
  // title: {
  //   text: 'Distibuted Treemap (different color for each cell)',
  //   align: 'center',
  // },

  dataLabels: {
    style: {
      colors: ['#333333'],
      fontSize: '21px',
      fontFamily: 'Helvetica, Arial, sans-serif',
      fontWeight: 'semibold',
    },
  },

  colors: [
    '#E4645B',
    '#E48C5B',
    '#E4AD5B',
    '#E4CE5B',
    '#B8E45B',
    '#14C393',
    '#65B67D',
    '#65ACB6',
    '#7EC3EA',
    '#7E96EA',
    '#4970BC',
    '#4970BC',
  ],
  plotOptions: {
    treemap: {
      distributed: true,
      enableShades: false,
    },
  },
};

export default function MyChart(series) {
  series = [
    {
      data: [
        {
          x: 'New_Delhi',
          y: 118,
        },
        {
          x: 'Kolkata',
          y: 149,
        },
        {
          x: 'Mumbai',
          y: 184,
        },
        {
          x: 'Ahmedabad',
          y: 55,
        },
        {
          x: 'Bangaluru',
          y: 84,
        },
        {
          x: 'Pune',
          y: 31,
        },
        {
          x: 'Chennai',
          y: 70,
        },
        {
          x: 'Jaipur',
          y: 30,
        },
        {
          x: 'Surat',
          y: 44,
        },
        {
          x: 'Hyderabad',
          y: 68,
        },
        {
          x: 'Lucknow',
          y: 28,
        },
        {
          x: 'Indore',
          y: 19,
        },
        {
          x: 'Kanpur',
          y: 29,
        },
      ],
    },
  ];

  return (
    <ReactApexChart
      options={options}
      series={series}
      type='treemap'
      height={250}
      width='100%'
    />
  );
}

// export default class MyChart extends React.Component {
//   constructor(props) {
//     super(props);

//     this.state = {
//       series: [
//         {
//           data: [
//             {
//               x: 'New Delhi',
//               y: 218,
//             },
//             {
//               x: 'Kolkata',
//               y: 149,
//             },
//             {
//               x: 'Mumbai',
//               y: 184,
//             },
//             {
//               x: 'Ahmedabad',
//               y: 55,
//             },
//             {
//               x: 'Bangaluru',
//               y: 84,
//             },
//             {
//               x: 'Pune',
//               y: 31,
//             },
//             {
//               x: 'Chennai',
//               y: 70,
//             },
//             {
//               x: 'Jaipur',
//               y: 30,
//             },
//             {
//               x: 'Surat',
//               y: 44,
//             },
//             {
//               x: 'Hyderabad',
//               y: 68,
//             },
//             {
//               x: 'Lucknow',
//               y: 28,
//             },
//             {
//               x: 'Indore',
//               y: 19,
//             },
//             {
//               x: 'Kanpur',
//               y: 29,
//             },
//           ],
//         },
//       ],
//       options: {
//         legend: {
//           show: false,
//         },
//         chart: {
//           height: 250,
//           type: 'treemap',
//         },
//         title: {
//           text: 'Distibuted Treemap (different color for each cell)',
//           align: 'center',
//         },
//         colors: [
//           '#3B93A5',
//           '#F7B844',
//           '#ADD8C7',
//           '#EC3C65',
//           '#CDD7B6',
//           '#C1F666',
//           '#D43F97',
//           '#1E5D8C',
//           '#421243',
//           '#7F94B0',
//           '#EF6537',
//           '#C0ADDB',
//         ],
//         plotOptions: {
//           treemap: {
//             distributed: true,
//             enableShades: false,
//           },
//         },
//       },
//     };
//   }

//   render() {
//     return (
//       <div id='chart'>
//         <ReactApexChart
//           options={this.state.options}
//           series={this.state.series}
//           type='treemap'
//           height={550}
//         />
//       </div>
//     );
//   }
// }
