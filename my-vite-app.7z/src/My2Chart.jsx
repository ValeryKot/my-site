import {React} from 'react';
import {TreeMapComponent} from '@syncfusion/ej2-react-treemap';
function My2Chart() {
  let data = [
    {State: 'Brazil', Count: 25},
    {State: 'Colombia', Count: 12},
    {State: 'Argentina', Count: 9},
    {State: 'Ecuador', Count: 7},
    {State: 'Chile', Count: 6},
    {State: 'Peru', Count: 3},
    {State: 'Venezuela', Count: 3},
    {State: 'Bolivia', Count: 2},
    {State: 'Paraguay', Count: 2},
    {State: 'Uruguay', Count: 2},
    {State: 'Falkland Islands', Count: 1},
    {State: 'French Guiana', Count: 1},
    {State: 'Guyana', Count: 1},
    {State: 'Suriname', Count: 1},
  ];
  return (
    <TreeMapComponent
      height='350px'
      dataSource={data}
      weightValuePath='Count'
      leafItemSettings={{
        labelPath: 'State',
        colorMapping: [
          {

            color: 'orange',
          },
          {

            color: 'green',
          },
          {
            color: 'red',
          },
        ],
      }}
    ></TreeMapComponent>
  );
}
export default My2Chart;
