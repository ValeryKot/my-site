import {useState} from 'react';
import reactLogo from './assets/react.svg';
import './App.css';
import ReactApexChart from 'react-apexcharts';
import MyChart from './MyChart';

import Treemap from './Treemap';
import data from './data';

const ser = [
  {
    data: [
      {
        x: 'New_Delhi',
        y: 118,
      },
      {
        x: 'Kolkata',
        y: 149,
      },
      {
        x: 'Mumbai',
        y: 184,
      },
      {
        x: 'Ahmedabad',
        y: 55,
      },
      {
        x: 'Bangaluru',
        y: 84,
      },
      {
        x: 'Pune',
        y: 31,
      },
      {
        x: 'Chennai',
        y: 70,
      },
      {
        x: 'Jaipur',
        y: 30,
      },
      {
        x: 'Surat',
        y: 44,
      },
      {
        x: 'Hyderabad',
        y: 68,
      },
      {
        x: 'Lucknow',
        y: 28,
      },
      {
        x: 'Indore',
        y: 19,
      },
      {
        x: 'Kanpur',
        y: 29,
      },
    ],
  },
];

const opt = {
  legend: {
    show: false,
  },
  chart: {
    height: 250,
    type: 'treemap',
  },
  // title: {
  //   text: 'Distibuted Treemap (different color for each cell)',
  //   align: 'center',
  // },
  colors: [
    '#3B93A5',
    '#F7B844',
    '#ADD8C7',
    '#EC3C65',
    '#CDD7B6',
    '#C1F666',
    '#D43F97',
    '#1E5D8C',
    '#421243',
    '#7F94B0',
    '#EF6537',
    '#C0ADDB',
  ],
  plotOptions: {
    treemap: {
      distributed: true,
      enableShades: false,
    },
  },
};

function App() {
  const [count, setCount] = useState(0);

  return (
    <div className='App'>
      <MyChart />
      <div>
        <a href='https://vitejs.dev' target='_blank'>
          <img src='/vite.svg' className='logo' alt='Vite logo' />
        </a>
        <a href='https://reactjs.org' target='_blank'>
          <img src={reactLogo} className='logo react' alt='React logo' />
        </a>
      </div>
      <h1>Vite + React</h1>
      <div className='card'>
        <button onClick={() => setCount((count) => count + 1)}>
          count is {count}
        </button>
        <p>
          Edit <code>src/App.jsx</code> and save to test HMR
        </p>
        <Treemap data={data} height={350} width={350} />
      </div>
      <p className='read-the-docs'>
        Click on the Vite and React logos to learn more
      </p>
    </div>
  );
}

export default App;
