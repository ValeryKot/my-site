function wrapText(selection) {
  selection.each(function () {
    const node = d3.select(this);
    const rectWidth = +node.attr('data-width');
    let word;
    const words = node.text().split(' ').reverse();
    let line = [];
    let lineNumber = 0;
    const x = node.attr('x');
    const y = node.attr('y');
    let tspan = node.text('').append('tspan').attr('x', x).attr('y', y);
    while (words.length > 1) {
      word = words.pop();
      line.push(word);
      tspan.text(line.join(' '));
      const tspanLength = tspan.node().getComputedTextLength();
      if (tspanLength > rectWidth && line.length !== 1) {
        line.pop();
        tspan.text(line.join(' '));
        line = [word];
        tspan = addTspan(word);
      }
    }
    addTspan(words.pop());

    function addTspan(text) {
      lineNumber += 1;
      return node
        .append('tspan')
        .attr('x', x)
        .attr('y', y)
        .attr('dy', `${lineNumber * fontSize}px`)
        .text(text);
    }
  });
}
